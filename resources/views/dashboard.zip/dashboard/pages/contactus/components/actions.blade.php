<div>
    <div class="row text-center">
        <a href="{{route('dashboard.make-reply',$contactus->id)}}"
           data-toggle="tooltip" title="{{__('app.edit')}}"
           class="btn btn-sm btn-icon btn-warning btn-active-light-primary me-2">
            <i class="fa fa-check"></i>
        </a>
    </div>
</div>
