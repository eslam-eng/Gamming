<script src="{{asset('assets/dashboard/plugins/datatable/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('assets/dashboard/plugins/datatable/js/dataTables.bootstrap5.js')}}"></script>
<script src="{{asset('assets/dashboard/plugins/datatable/dataTables.responsive.min.js')}}"></script>
{!! $dataTable->scripts() !!}
