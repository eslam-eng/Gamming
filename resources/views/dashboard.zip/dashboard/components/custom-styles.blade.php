		<!-- Favicon -->
		<link rel="icon" href="{{asset('assets/dashboard/images/brand/logo.png')}}" type="image/x-icon"/>

		<!-- Icons css -->
		<link href="{{asset('assets/dashboard/plugins/icons/icons.css')}}" rel="stylesheet">

		<!--  bootstrap css-->
		<link href="{{asset('assets/dashboard/plugins/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" />

		<!--  Right-sidemenu css -->
		<link href="{{asset('assets/dashboard/plugins/sidebar/sidebar.css')}}" rel="stylesheet">

		<!-- P-scroll bar css-->
		<link href="{{asset('assets/dashboard/plugins/perfect-scrollbar/p-scrollbar.css')}}" rel="stylesheet" />
        <link href="{{asset('assets/dashboard/plugins/toastr/toastr.min.css')}}" rel="stylesheet">


        @yield('styles')

		<!--- Style css --->
		<link href="{{asset('assets/dashboard/css/style.css')}}" rel="stylesheet">
		<link href="{{asset('assets/dashboard/css/style-dark.css')}}" rel="stylesheet">
		<link href="{{asset('assets/dashboard/css/style-transparent.css')}}" rel="stylesheet">

		<!---Skinmodes css-->
		<link href="{{asset('assets/dashboard/css/skin-modes.css')}}" rel="stylesheet" />

		<!--- Animations css-->
		<link href="{{asset('assets/dashboard/css/animate.css')}}" rel="stylesheet">
