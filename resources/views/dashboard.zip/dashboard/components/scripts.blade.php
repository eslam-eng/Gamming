		<!-- BACK-TO-TOP -->
		<a href="#top" id="back-to-top"><i class="las la-arrow-up"></i></a>

		<!-- JQUERY JS -->
		<script src="{{asset('assets/dashboard/plugins/jquery/jquery.min.js')}}"></script>

		<!-- BOOTSTRAP JS -->
		<script src="{{asset('assets/dashboard/plugins/bootstrap/js/popper.min.js')}}"></script>
		<script src="{{asset('assets/dashboard/plugins/bootstrap/js/bootstrap.min.js')}}"></script>

		<!-- IONICONS JS -->
		<script src="{{asset('assets/dashboard/plugins/ionicons/ionicons.js')}}"></script>

		<!-- MOMENT JS -->
		<script src="{{asset('assets/dashboard/plugins/moment/moment.js')}}"></script>

		<!-- P-SCROLL JS -->
		<script src="{{asset('assets/dashboard/plugins/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
		<script src="{{asset('assets/dashboard/plugins/perfect-scrollbar/p-scroll.js')}}"></script>

		<!-- SIDEBAR JS -->
		<script src="{{asset('assets/dashboard/plugins/side-menu/sidemenu.js')}}"></script>

		<!-- STICKY JS -->
		<script src="{{asset('assets/dashboard/js/sticky.js')}}"></script>

		<!-- Chart-circle js -->
		<script src="{{asset('assets/dashboard/plugins/circle-progress/circle-progress.min.js')}}"></script>

		<!-- RIGHT-SIDEBAR JS -->
		<script src="{{asset('assets/dashboard/plugins/sidebar/sidebar.js')}}"></script>
		<script src="{{asset('assets/dashboard/plugins/sidebar/sidebar-custom.js')}}"></script>

        @yield('scripts')

		<!-- EVA-ICONS JS -->
		<script src="{{asset('assets/dashboard/plugins/eva-icons/eva-icons.min.js')}}"></script>

		<!-- THEME-COLOR JS -->
		<script src="{{asset('assets/dashboard/js/themecolor.js')}}"></script>

        <script src="{{asset('assets/dashboard/plugins/sweet-alert/sweetalert.min.js')}}"></script>
        <script src="{{asset('assets/dashboard/plugins/toastr/toastr.min.js')}}"></script>
		<!-- CUSTOM JS -->
		<script src="{{asset('assets/dashboard/js/custom.js')}}"></script>

		<!-- exported JS -->
		<script src="{{asset('assets/dashboard/js/exported.js')}}"></script>


