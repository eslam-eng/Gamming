			<!-- Footer opened -->
			<div class="main-footer">
				<div class="container-fluid pd-t-0-f ht-100p">
					 Copyright © 2024 <a href="javascript:void(0);" class="text-primary">Aknana</a> All rights reserved
				</div>
			</div>
			<!-- Footer closed -->
