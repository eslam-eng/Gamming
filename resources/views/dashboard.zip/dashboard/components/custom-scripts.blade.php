		<!-- JQuery min js -->
		<script src="{{asset('assets/dashboard/plugins/jquery/jquery.min.js')}}"></script>

		<!-- Bootstrap js -->
		<script src="{{asset('assets/dashboard/plugins/bootstrap/js/popper.min.js')}}"></script>
		<script src="{{asset('assets/dashboard/plugins/bootstrap/js/bootstrap.min.js')}}"></script>

		<!-- Ionicons js -->
		<script src="{{asset('assets/dashboard/plugins/ionicons/ionicons.js')}}"></script>

		<!-- Moment js -->
		<script src="{{asset('assets/dashboard/plugins/moment/moment.js')}}"></script>

		<!-- eva-icons js -->
		<script src="{{asset('assets/dashboard/plugins/eva-icons/eva-icons.min.js')}}"></script>

        @yield('scripts')

		<!-- generate-otp js -->
		<script src="{{asset('assets/dashboard/js/generate-otp.js')}}"></script>

		<!--Internal  Perfect-scrollbar js -->
		<script src="{{asset('assets/dashboard/plugins/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>

		<!-- THEME-COLOR JS -->
		<script src="{{asset('assets/dashboard/js/themecolor.js')}}"></script>

		<!-- CUSTOM JS -->
		<script src="{{asset('assets/dashboard/js/custom.js')}}"></script>

		<!-- exported JS -->
		<script src="{{asset('assets/dashboard/js/exported.js')}}"></script>

        <script src="{{asset('assets/dashboard/plugins/toastr/toastr.min.js')}}"></script>
